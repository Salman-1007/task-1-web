// This file was added during a feature change and is intentionally left blank
// to restore the repository to its previous state. Remove this file if re-adding
// authentication features in the future.
module.exports = {};