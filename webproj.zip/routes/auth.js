// Auth routes were added during a feature change. Left intentionally blank to
// revert project to prior state. If you want these restored, I'll re-add them
// fully.
module.exports = {};