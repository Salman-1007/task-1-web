// Diagnostic compile script removed during revert. If you need this,
// I can reintroduce a clean version later.
console.log('diagnostic script removed');