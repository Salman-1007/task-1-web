require('dotenv').config();
const express = require('express');
const path = require('path');
const connectDB = require('./config/database');

// Connect to MongoDB
connectDB();

const app = express();

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Session middleware

// Middleware for parsing JSON and URL-encoded data
app.use(express.json());
app.use(express.urlencoded({
    extended: true
}));

// Middleware to expose session user and cart count to views

// Serve static files (CSS, JS, images)
app.use('/css', express.static(path.join(__dirname, 'public', 'css')));
app.use('/js', express.static(path.join(__dirname, 'public', 'js')));
app.use('/images', express.static(path.join(__dirname, 'images')));

// Routes
const routes = require('./routes');
const adminRoutes = require('./routes/admin');

app.use('/', routes);
app.use('/admin', adminRoutes);

// 404 handler
app.use((req, res) => {
    res.status(404).render('404', {
        title: 'Page Not Found'
    });
});

module.exports = app;